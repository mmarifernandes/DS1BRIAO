<?php

echo"Nome:"."<br>";
echo $nome;

?>