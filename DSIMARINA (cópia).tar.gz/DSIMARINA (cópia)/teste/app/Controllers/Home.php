<?php

namespace App\Controllers;

class Home extends BaseController
{
    public function index()
    {
        return view('formulario');
    }
    public function registro()
    {
        // echo 'Foi';
        $nome = $this->request->getVar('nome');
        $data['nome']=$nome;
        return view('result', $data);
    }
}
