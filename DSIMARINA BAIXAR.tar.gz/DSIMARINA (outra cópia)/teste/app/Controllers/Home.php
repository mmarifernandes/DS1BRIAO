<?php

namespace App\Controllers;
use App\Models\Itens;


class Home extends BaseController
{
    public function index()
    {
        return view('formulario');
    }
    public function registro()
    {
        // echo 'Foi';
        $nome = $this->request->getVar('nome');
        $idade = $this->request->getVar('idade');
        $descricao = $this->request->getVar('descricao');

        $data['nome']=$nome;
        $data['idade']=$idade;
        $data['descricao']=$descricao;

        $itensModel = new Itens();
        $itensModel -> insert($data);
        return redirect() -> to(base_url('/'));
        // return view('result', $data);
    }
}
