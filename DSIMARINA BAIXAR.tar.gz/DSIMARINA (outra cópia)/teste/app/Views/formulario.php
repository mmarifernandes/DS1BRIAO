<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Nosso primeiro App</h1>
<div>

<form action="/enviar" method="post">

<label for="nome">Nome:</label>
<input type="text" name="nome">
<label for="idade">Idade:</label>
<input type="number" name="idade">
<label for="descricao">Descrição:</label>
<input type="text" name="descricao">
<button type="submit">Enviar</button>

</form>
</div>
</body>
</html>