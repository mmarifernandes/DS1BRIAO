<?php

echo"Nome: ";
echo $nome;
echo "<br>";
echo"Idade: ";
echo $idade;
echo "<br>";
echo"Descrição: ";
echo $descricao;

?>