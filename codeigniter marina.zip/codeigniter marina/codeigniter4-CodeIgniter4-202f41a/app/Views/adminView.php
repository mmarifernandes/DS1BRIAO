<a href="<?php echo base_url()?>/registrationcliente">
   <button>Cadastrar Cliente</button>
</a>
<a href="<?php echo base_url()?>/registrationproduto">
<button>Cadastrar Produtos</button>
</a>
<a href="<?php echo base_url()?>/insertformorder">
<button>Fazer Compra</button>
</a>
<a href="<?php echo base_url()?>/insertformorder">
<button>Cadastrar Categorias</button>
</a>




<table class="table">
  <thead class="thead-light">
    <tr>
      <th scope="col">Name</th>
      <th scope="col">E-mail</th>
      <th scope="col">Cidade</th>
     

    </tr>
  </thead>
  <tbody>

<?php
    foreach ($customers as $customer){
        if ($customer['Nome']=='Admin') continue;
        echo "<tr class=\"table-light\">
        <td>".$customer['Nome']."</td>
        <td>".$customer['Email']."</td>
        <td>".$customer['Cidade']."</td></tr>";

        
    }
?>
    
<tr><td>
            <table class="table table-light">
            <thead>
                <tr>
                <th scope="col">#</th>
                <th scope="col">Description order(s)</th>
                <th scope="col">Amount</th>
                <th scope="col"></th>
                </tr>
            </thead>

            <tbody>
          
            </body>
           
            </table>
         </td></tr>   

    </body>
</table>